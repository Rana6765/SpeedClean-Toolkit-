<?php
/*
Plugin Name: SpeedClean Toolkit
Description: A performance plugin to clean old posts, optimize images, clear cache, remove emoji scripts, and control Heartbeat.
Version: 1.0
Author: Webloop
License: GPL876
*/

// Prevent direct access to this file
if (!defined('ABSPATH')) {
    exit;
}

// Add settings page
function sct_admin_menu() {
    add_menu_page(
        'SpeedClean Toolkit',
        'SpeedClean Toolkit',
        'manage_options',
        'sct-settings',
        'sct_settings_page',
        'dashicons-performance',
        95
    );
}
add_action('admin_menu', 'sct_admin_menu');

// Register settings
function sct_register_settings() {
    // Old Post Cleaner
    register_setting('sct_settings_group', 'sct_enable_post_cleaner', ['sanitize_callback' => 'absint']);
    register_setting('sct_settings_group', 'sct_clean_drafts', ['sanitize_callback' => 'absint']);
    register_setting('sct_settings_group', 'sct_clean_revisions', ['sanitize_callback' => 'absint']);
    register_setting('sct_settings_group', 'sct_clean_age_days', ['sanitize_callback' => 'absint']);
    // Media Optimizer
    register_setting('sct_settings_group', 'sct_enable_media_optimizer', ['sanitize_callback' => 'absint']);
    register_setting('sct_settings_group', 'sct_tinypng_api_key', ['sanitize_callback' => 'sanitize_text_field']);
    // Simple Cache Clear Button
    register_setting('sct_settings_group', 'sct_enable_cache_clear', ['sanitize_callback' => 'absint']);
    // Emoji Remover
    register_setting('sct_settings_group', 'sct_enable_emoji_remover', ['sanitize_callback' => 'absint']);
    // Heartbeat Control
    register_setting('sct_settings_group', 'sct_enable_heartbeat_control', ['sanitize_callback' => 'absint']);
    register_setting('sct_settings_group', 'sct_admin_interval', ['sanitize_callback' => 'absint']);
    register_setting('sct_settings_group', 'sct_editor_interval', ['sanitize_callback' => 'absint']);
    register_setting('sct_settings_group', 'sct_frontend_interval', ['sanitize_callback' => 'absint']);
    register_setting('sct_settings_group', 'sct_disable_admin', ['sanitize_callback' => 'absint']);
    register_setting('sct_settings_group', 'sct_disable_editor', ['sanitize_callback' => 'absint']);
    register_setting('sct_settings_group', 'sct_disable_frontend', ['sanitize_callback' => 'absint']);
}
add_action('admin_init', 'sct_register_settings');

// Settings page
function sct_settings_page() {
    ?>
    <div class="wrap">
        <h1>SpeedClean Toolkit</h1>
        <p>Optimize your WordPress site with cleanup and performance tools.</p>
        <form method="post" action="options.php">
            <?php settings_fields('sct_settings_group'); ?>
            <?php do_settings_sections('sct_settings_group'); ?>
            <h2>Old Post Cleaner</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="sct_enable_post_cleaner">Enable Post Cleaner</label></th>
                    <td>
                        <input type="checkbox" id="sct_enable_post_cleaner" name="sct_enable_post_cleaner" value="1" <?php checked(get_option('sct_enable_post_cleaner', 1)); ?> />
                        <p class="description">Enable automatic cleanup of old drafts and revisions.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sct_clean_drafts">Clean Drafts</label></th>
                    <td>
                        <input type="checkbox" id="sct_clean_drafts" name="sct_clean_drafts" value="1" <?php checked(get_option('sct_clean_drafts', 1)); ?> />
                        <p class="description">Remove old auto-drafts and drafts.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sct_clean_revisions">Clean Revisions</label></th>
                    <td>
                        <input type="checkbox" id="sct_clean_revisions" name="sct_clean_revisions" value="1" <?php checked(get_option('sct_clean_revisions', 1)); ?> />
                        <p class="description">Remove old post revisions.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sct_clean_age_days">Age Threshold (Days)</label></th>
                    <td>
                        <input type="number" id="sct_clean_age_days" name="sct_clean_age_days" value="<?php echo esc_attr(get_option('sct_clean_age_days', 30)); ?>" min="1" />
                        <p class="description">Delete drafts/revisions older than this many days (default: 30).</p>
                    </td>
                </tr>
            </table>
            <h2>Media Optimizer</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="sct_enable_media_optimizer">Enable Media Optimizer</label></th>
                    <td>
                        <input type="checkbox" id="sct_enable_media_optimizer" name="sct_enable_media_optimizer" value="1" <?php checked(get_option('sct_enable_media_optimizer', 0)); ?> />
                        <p class="description">Compress images on upload using TinyPNG API.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sct_tinypng_api_key">TinyPNG API Key</label></th>
                    <td>
                        <input type="text" id="sct_tinypng_api_key" name="sct_tinypng_api_key" value="<?php echo esc_attr(get_option('sct_tinypng_api_key', '')); ?>" class="regular-text" />
                        <p class="description">Get your API key from <a href="https://tinypng.com/developers" target="_blank">tinypng.com</a>.</p>
                    </td>
                </tr>
            </table>
            <h2>Simple Cache Clear Button</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="sct_enable_cache_clear">Enable Cache Clear Button</label></th>
                    <td>
                        <input type="checkbox" id="sct_enable_cache_clear" name="sct_enable_cache_clear" value="1" <?php checked(get_option('sct_enable_cache_clear', 1)); ?> />
                        <p class="description">Add a "Clear Cache" button to the admin bar.</p>
                    </td>
                </tr>
            </table>
            <h2>Emoji Remover</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="sct_enable_emoji_remover">Enable Emoji Remover</label></th>
                    <td>
                        <input type="checkbox" id="sct_enable_emoji_remover" name="sct_enable_emoji_remover" value="1" <?php checked(get_option('sct_enable_emoji_remover', 1)); ?> />
                        <p class="description">Remove emoji scripts and styles to improve speed.</p>
                    </td>
                </tr>
            </table>
            <h2>Heartbeat Control</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="sct_enable_heartbeat_control">Enable Heartbeat Control</label></th>
                    <td>
                        <input type="checkbox" id="sct_enable_heartbeat_control" name="sct_enable_heartbeat_control" value="1" <?php checked(get_option('sct_enable_heartbeat_control', 1)); ?> />
                        <p class="description">Reduce Heartbeat API frequency to lower server load.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sct_admin_interval">Admin Area Interval (seconds)</label></th>
                    <td>
                        <input type="number" id="sct_admin_interval" name="sct_admin_interval" value="<?php echo esc_attr(get_option('sct_admin_interval', 120)); ?>" min="15" max="600" />
                        <p class="description">Heartbeat interval for admin dashboard (default: 120 seconds).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sct_disable_admin">Disable in Admin Area</label></th>
                    <td>
                        <input type="checkbox" id="sct_disable_admin" name="sct_disable_admin" value="1" <?php checked(get_option('sct_disable_admin', 0)); ?> />
                        <p class="description">Disable Heartbeat in admin area (except post editor).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sct_editor_interval">Post Editor Interval (seconds)</label></th>
                    <td>
                        <input type="number" id="sct_editor_interval" name="sct_editor_interval" value="<?php echo esc_attr(get_option('sct_editor_interval', 60)); ?>" min="15" max="600" />
                        <p class="description">Heartbeat interval for post/page editor (default: 60 seconds).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sct_disable_editor">Disable in Post Editor</label></th>
                    <td>
                        <input type="checkbox" id="sct_disable_editor" name="sct_disable_editor" value="1" <?php checked(get_option('sct_disable_editor', 0)); ?> />
                        <p class="description">Disable Heartbeat in post editor (may affect autosave).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sct_frontend_interval">Front-End Interval (seconds)</label></th>
                    <td>
                        <input type="number" id="sct_frontend_interval" name="sct_frontend_interval" value="<?php echo esc_attr(get_option('sct_frontend_interval', 120)); ?>" min="15" max="600" />
                        <p class="description">Heartbeat interval for front-end (default: 120 seconds).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sct_disable_frontend">Disable on Front-End</label></th>
                    <td>
                        <input type="checkbox" id="sct_disable_frontend" name="sct_disable_frontend" value="1" <?php checked(get_option('sct_disable_frontend', 0)); ?> />
                        <p class="description">Disable Heartbeat on front-end.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
        <h2>Setup Instructions</h2>
        <ol>
            <li>Activate the plugin to enable default settings.</li>
            <li>Configure each feature above and save changes.</li>
            <li>For <strong>Media Optimizer</strong>, get a TinyPNG API key from <a href="https://tinypng.com/developers" target="_blank">tinypng.com</a>.</li>
            <li>Test features: upload an image, submit a form, clear cache, check page source for emoji scripts, and monitor Heartbeat requests.</li>
        </ol>
        <h2>How It Works</h2>
        <ul>
            <li><strong>Old Post Cleaner</strong>: Deletes old drafts and revisions daily to reduce database size.</li>
            <li><strong>Media Optimizer</strong>: Compresses JPEG/PNG images on upload using TinyPNG API.</li>
            <li><strong>Simple Cache Clear Button</strong>: Adds a one-click cache clear button to the admin bar.</li>
            <li><strong>Emoji Remover</strong>: Removes emoji scripts and styles to reduce page load time.</li>
            <li><strong>Heartbeat Control</strong>: Reduces or disables Heartbeat API calls to lower server load.</li>
        </ul>
        <p><strong>Note:</strong> Back up your site before cleaning posts. Ensure cURL is enabled for TinyPNG API. Test cache clearing with your caching plugin. Use tools like GTmetrix to measure speed improvements.</p>
    </div>
    <?php
}

// Old Post Cleaner
function sct_schedule_post_cleanup() {
    if (!wp_next_scheduled('sct_cleanup_posts_event')) {
        wp_schedule_event(time(), 'daily', 'sct_cleanup_posts_event');
    }
}
add_action('wp', 'sct_schedule_post_cleanup');

function sct_cleanup_posts() {
    if (!get_option('sct_enable_post_cleaner', 1)) {
        return;
    }

    global $wpdb;
    $age_days = absint(get_option('sct_clean_age_days', 30));
    $date_threshold = gmdate('Y-m-d H:i:s', strtotime("-$age_days days"));

    if (get_option('sct_clean_drafts', 1)) {
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM $wpdb->posts WHERE post_status IN ('draft', 'auto-draft') AND post_date < %s",
                $date_threshold
            )
        );
    }

    if (get_option('sct_clean_revisions', 1)) {
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM $wpdb->posts WHERE post_type = 'revision' AND post_date < %s",
                $date_threshold
            )
        );
    }
}
add_action('sct_cleanup_posts_event', 'sct_cleanup_posts');

// Media Optimizer
function sct_optimize_image($attachment_id) {
    if (!get_option('sct_enable_media_optimizer', 0) || !function_exists('curl_init')) {
        return;
    }

    $api_key = get_option('sct_tinypng_api_key', '');
    if (empty($api_key)) {
        error_log('SpeedClean Toolkit: TinyPNG API key missing.');
        return;
    }

    $image_path = get_attached_file($attachment_id);
    $image_type = wp_check_filetype($image_path)['ext'];
    if (!in_array(strtolower($image_type), ['jpg', 'jpeg', 'png'])) {
        return;
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.tinify.com/shrink');
    curl_setopt($ch, CURLOPT_USERPWD, 'api:' . $api_key);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, file_get_contents($image_path));

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code !== 201 || !$response) {
        error_log('SpeedClean Toolkit: TinyPNG API error - HTTP ' . $http_code . ': ' . $response);
        return;
    }

    $data = json_decode($response, true);
    if (empty($data['output']['url'])) {
        error_log('SpeedClean Toolkit: TinyPNG API response missing output URL.');
        return;
    }

    $compressed_url = $data['output']['url'];
    $compressed_data = wp_remote_get($compressed_url, ['timeout' => 30]);

    if (is_wp_error($compressed_data) || wp_remote_retrieve_response_code($compressed_data) !== 200) {
        error_log('SpeedClean Toolkit: Failed to download compressed image.');
        return;
    }

    file_put_contents($image_path, wp_remote_retrieve_body($compressed_data));
}
add_action('add_attachment', 'sct_optimize_image');

// Simple Cache Clear Button (reusing artifact_id from previous request)
function sct_add_cache_clear_button($wp_admin_bar) {
    if (!get_option('sct_enable_cache_clear', 1) || !current_user_can('manage_options')) {
        return;
    }

    $wp_admin_bar->add_node([
        'id' => 'sct-clear-cache',
        'title' => __('Clear Cache', 'speedclean-toolkit'),
        'href' => wp_nonce_url(admin_url('?sct_clear_cache=1'), 'sct_clear_cache_action'),
        'meta' => [
            'title' => __('Clear all caches with one click', 'speedclean-toolkit'),
        ],
    ]);
}
add_action('admin_bar_menu', 'sct_add_cache_clear_button', 100);

function sct_clear_cache() {
    if (!isset($_GET['sct_clear_cache']) || !get_option('sct_enable_cache_clear', 1) || !current_user_can('manage_options')) {
        return;
    }

    if (!wp_verify_nonce($_GET['_wpnonce'], 'sct_clear_cache_action')) {
        wp_die(__('Security check failed.', 'speedclean-toolkit'), __('Error', 'speedclean-toolkit'), ['response' => 403]);
    }

    // Clear WordPress object cache
   :

    wp_cache_flush();

    // Clear popular caching plugins
    if (function_exists('wp_cache_clear_cache')) {
        wp_cache_clear_cache();
    }

    if (function_exists('w3tc_flush_all')) {
        w3tc_flush_all();
    }

    if (class_exists('LiteSpeed_Cache_API')) {
        LiteSpeed_Cache_API::purge_all();
    }

    if (function_exists('rocket_clean_domain')) {
        rocket_clean_domain();
    }

    // Clear transients
    global $wpdb;
    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_%' OR option_name LIKE '_site_transient_%'");

    wp_safe_redirect(add_query_arg([
        'sct_cache_cleared' => '1',
    ], wp_get_referer()));
    exit;
}
add_action('admin_init', 'sct_clear_cache');

function sct_cache_clear_notice() {
    if (isset($_GET['sct_cache_cleared']) && $_GET['sct_cache_cleared'] == '1' && current_user_can('manage_options')) {
        ?>
        <div class="notice notice-success is-dismissible">
            <p><?php _e('All caches have been cleared successfully!', 'speedclean-toolkit'); ?></p>
        </div>
        <?php
    }
}
add_action('admin_notices', 'sct_cache_clear_notice');

// Emoji Remover (reusing artifact_id from previous request)
function sct_disable_emojis() {
    if (!get_option('sct_enable_emoji_remover', 1)) {
        return;
    }

    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
    add_filter('emoji_svg_url', '__return_false');
    add_filter('tiny_mce_plugins', 'sct_disable_emojis_tinymce');
}

function sct_disable_emojis_tinymce($plugins) {
    if (is_array($plugins)) {
        return array_diff($plugins, ['wpemoji']);
    }
    return [];
}
add_action('init', 'sct_disable_emojis');

// Heartbeat Control (reusing artifact_id from previous request)
function sct_modify_heartbeat_settings($settings) {
    if (!get_option('sct_enable_heartbeat_control', 1)) {
        return $settings;
    }

    $admin_interval = absint(get_option('sct_admin_interval', 120));
    $editor_interval = absint(get_option('sct_editor_interval', 60));
    $frontend_interval = absint(get_option('sct_frontend_interval', 120));

    if (is_admin() && !sct_is_post_editor()) {
        if (get_option('sct_disable_admin', 0)) {
            add_filter('heartbeat_send', '__return_false');
        } elseif ($admin_interval >= 15) {
            $settings['interval'] = $admin_interval;
        }
    } elseif (sct_is_post_editor()) {
        if (get_option('sct_disable_editor', 0)) {
            add_filter('heartbeat_send', '__return_false');
        } elseif ($editor_interval >= 15) {
            $settings['interval'] = $editor_interval;
        }
    } else {
        if (get_option('sct_disable_frontend', 0)) {
            add_filter('heartbeat_send', '__return_false');
        } elseif ($frontend_interval >= 15) {
            $settings['interval'] = $frontend_interval;
        }
    }

    return $settings;
}
add_filter('heartbeat_settings', 'sct_modify_heartbeat_settings');

function sct_is_post_editor() {
    global $pagenow;
    return in_array($pagenow, ['post.php', 'post-new.php']);
}
?>